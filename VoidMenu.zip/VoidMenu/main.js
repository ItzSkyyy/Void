//contents of jvoid
let javoid = document.createElement("div");
//style stuff
    javoid.style.background = "rgb(33, 33, 33)";
    javoid.style.width = "150px";
    javoid.style.height = "240px";
    javoid.style.position = "fixed";
    javoid.style.top = "0px";
    javoid.style.left = "0px";
    javoid.style.zIndex = "99999999";
    javoid.style.opacity = "0.85";
    javoid.style.borderRadius = "10px";
    javoid.style.border = "2px solid purple";
    javoid.style.fontFamily = "sans-serif";
    javoid.style.textAlign = "center";
    javoid.style.lineHeight = "0.1";
    javoid.style.fontWeight = "bold";
//end
javoid.id = "jav"; //THIS IS THE ID IF YOU WANT TO USE IT.
//inner html
javoid.innerHTML = `
<style>
.hd {
  color: rgb(140, 0, 255);
  font-size:25px;
}

.subhd {
  color: rgb(140, 0, 255);
  font-size:15px;
}

.pr {
  font-size: 10px;
  color:rgb(255,255,255);
  text-decoration: none;
}

.nbu { 
  color:white;
  background:transparent;
  border:solid 0px;
  width:150px;
  font-size:15px;
  transition: all 0.25s;
  border-radius: 10px;
  font-Weight:bold;
}

.nbu:hover {
  background: rgba(20, 20, 20);
  color: rgb(144, 0, 255);
  font-size:17px;
}

</style>
<img src="https://cdn.glitch.me/3ffb250d-17ed-4059-96f6-b63105c97664/logo.png" width="40px"></img>

  <h1 class="hd">Void<span style="color:rgb(0, 0, 0);text-shadow: 0px 0px 5px rgba(102,0,255,1), 0px 0px 5px rgba(102,0,255,1);">Menu</span><h1>

  <p class="subhd">2.0<p>

<button id="cheatz" class="nbu" style="position:absolute;top:90px;left:0px;">Cheats</span></button> 

<button id="chtagpt" class="nbu" style="position:absolute;top:110px;left:0px;">ChatGPT</span></button> 

<button id="diskard" class="nbu" style="position:absolute;top:130px;left:0px;">Discord</span></button> 

<button id="thamas" class="nbu" style="position:absolute;top:150px;left:0px;color:grey">Themes</span></button> 

<button id="creeditz" class="nbu" style="position:absolute;top:170px;left:0px;">Credits</span></button> 

<button id="outher" class="nbu" style="position:absolute;top:190px;left:0px;color:grey">Other</span></button> 
  
<button id="close" class="nbu" style="position:absolute;bottom:3px;left:0px;">Exit</button>  
  `
document.body.appendChild(javoid);
//end of contents

//draggable menu function.
javoid.addEventListener("mousedown", function(event) {
	let startX = event.clientX;
	let startY = event.clientY;
	let origX = javoid.style.left;
	let origY = javoid.style.top;

	document.addEventListener('mousemove', move);

	function move(event) {
		let deltaX = event.clientX - startX;
		let deltaY = event.clientY - startY;

		javoid.style.left = (parseInt(origX) + deltaX) + 'px';
		javoid.style.top  = (parseInt(origY) + deltaY) + 'px';
	}

	document.addEventListener('mouseup', () => {
		document.removeEventListener('mousemove', move);
	});
});
//end of draggable

//beginning of balls corparation


//button clicks for javoid menu (do get element by id)

document.getElementById('close').onclick = closemenu;
document.getElementById('cheatz').onclick = openCheatz;
document.getElementById('diskard').onclick = diskard
document.getElementById('chtagpt').onclick = OpenGPT
document.getElementById('creeditz').onclick = opencreeditz

//javoid menu Functions


function closeCheatz() {

console.log('cheetz element was removed succesfully')
document.getElementById('cheetz').remove();
  
}


//cheatz functions
function opencreeditz() {

  if (document.getElementById('creeditzmenu')) {
  document.getElementById('creeditzmenu').remove();
  } else {
  
  let creeditzmenu = document.createElement("div");
  //style stuff
    creeditzmenu.style.background = "rgb(33, 33, 33)";
    creeditzmenu.style.width = "150px";
    creeditzmenu.style.height = "200px";
    creeditzmenu.style.position = "fixed";
    creeditzmenu.style.top = "0px";
    creeditzmenu.style.left = "0px";
    creeditzmenu.style.zIndex = "99999999";
    creeditzmenu.style.opacity = "0.85";
    creeditzmenu.style.borderRadius = "10px";
    creeditzmenu.style.border = "2px solid purple";
    creeditzmenu.style.fontFamily = "sans-serif";
    creeditzmenu.style.textAlign = "center";
    creeditzmenu.style.lineHeight = "0.1";
    creeditzmenu.style.fontWeight = "bold";
  //end
  creeditzmenu.id = "creeditzmenu"; //THIS IS THE ID IF YOU WANT TO USE IT.
  //inner html
  creeditzmenu.innerHTML = `
  <style>
  .hd {
    color: rgb(140, 0, 255);
    font-size:25px;
  }
  
  .pr {
    font-size: 10px;
    color:rgb(255,255,255);
    text-decoration: none;
  }
  
  .nbu { 
    color:white;
    background:transparent;
    border:solid 0px;
    width:150px;
    font-size:15px;
    transition: all 0.25s;
    border-radius: 10px;
    font-Weight:bold;
  }
  
  .nbu:hover {
    background: rgba(20, 20, 20);
    color: rgb(144, 0, 255);
    font-size:17px;
  }

  </style>
  
    <h1 class="hd">VoidMenu<span style="color:rgb(0, 0, 0);text-shadow: 0px 0px 5px rgba(102,0,255,1), 0px 0px 5px rgba(102,0,255,1); position:absolute;top:40px;left:30px;">\nCredits</span><h1>
  
  <button id="creditzj4v" class="nbu" style="position:absolute;top:60px;left:0px;">J4V</button> 

  <button id="creditzskyyy" class="nbu" style="position:absolute;top:100px;left:0px;">ItzSkyyy</button> 
  
  <button id="creditzzeakify" class="nbu" style="position:absolute;top:80px;left:0px;">Zeakify</button>  
    
  <button id="closecreeditz" class="nbu" style="position:absolute;bottom:5px;left:0px;">Exit</button>  
    `
  document.body.appendChild(creeditzmenu);

document.getElementById('creditzj4v').onclick = creditzj4v;  document.getElementById('creditzzeakify').onclick = creditzzeakify;
document.getElementById('creditzskyyy').onclick = creditzskyyy;
document.getElementById('closecreeditz').onclick = closecreeditz;
  

creeditzmenu.addEventListener("mousedown", function(event) {
	let startX = event.clientX;
	let startY = event.clientY;
	let origX = creeditzmenu.style.left;
	let origY = creeditzmenu.style.top;

	document.addEventListener('mousemove', move);

	function move(event) {
		let deltaX = event.clientX - startX;
		let deltaY = event.clientY - startY;

		creeditzmenu.style.left = (parseInt(origX) + deltaX) + 'px';
		creeditzmenu.style.top  = (parseInt(origY) + deltaY) + 'px';
	}

	document.addEventListener('mouseup', () => {
		document.removeEventListener('mousemove', move);
	});
});
};
}

function closecreeditz() {
    
console.log('creeditz element was removed succesfully')  
document.getElementById('creeditzmenu').remove();
  
}

//this is all the credits profiles  
//
//
//
//
//
//
//
//
function creditzj4v() {

if (document.getElementById('creditzj4vid')) {
  document.getElementById('creditzj4vid').remove();
  } else {
  
  let creditzj4v = document.createElement("div");
//style stuff
    creditzj4v.style.background = "rgb(33, 33, 33)";
    creditzj4v.style.width = "150px";
    creditzj4v.style.height = "200px";
    creditzj4v.style.position = "fixed";
    creditzj4v.style.top = "0px";
    creditzj4v.style.left = "0px";
    creditzj4v.style.zIndex = "99999999";
    creditzj4v.style.opacity = "0.85";
    creditzj4v.style.borderRadius = "10px";
    creditzj4v.style.border = "2px solid purple";
    creditzj4v.style.fontFamily = "sans-serif";
    creditzj4v.style.textAlign = "center";
    creditzj4v.style.lineHeight = "0.1";
    creditzj4v.style.fontWeight = "bold";
//end
creditzj4v.id = "creditzj4vid"; //THIS IS THE ID IF YOU WANT TO USE IT.
//inner html
creditzj4v.innerHTML = `
<style>
.hd {
  color: rgb(140, 0, 255);
  font-size:25px;
}

.pr {
  font-size: 10px;
  color:rgb(255,255,255);
  text-decoration: none;
}

.nbu { 
  color:white;
  background:transparent;
  border:solid 0px;
  width:150px;
  font-size:15px;
  transition: all 0.25s;
  border-radius: 10px;
  font-Weight:bold;
}

.nbu:hover {
  background: rgba(20, 20, 20);
  color: rgb(144, 0, 255);
  font-size:17px;
}

img {

border: 5px solid #6600e1;
border-radius: 45px;

}

h5 {
color: white;
}

</style>

<img id="j4vPFP" src="https://cdn.discordapp.com/avatars/1076258927118929990/a_7939107e9a8ce614dafb34c7094f0be0.gif?size=80">


  <h1 class="hd">J<span style="color:rgb(0, 0, 0);text-shadow: 0px 0px 5px rgba(102,0,255,1), 0px 0px 5px rgba(102,0,255,1);">4<span class="hd">V</span></span><h1>

<h5>Owner</h5>

<button id="closecreditzj4v" class="nbu" style="position:absolute;bottom:5px;left:0px;">Exit</button>  
  `
document.body.appendChild(creditzj4v);


  document.getElementById('closecreditzj4v').onclick = closecreditzj4v
//cheatzMenu menu button clicks (use getElementById)
  


 

  
creditzj4v.addEventListener("mousedown", function(event) {
	let startX = event.clientX;
	let startY = event.clientY;
	let origX = creditzj4v.style.left;
	let origY = creditzj4v.style.top;

	document.addEventListener('mousemove', move);

	function move(event) {
		let deltaX = event.clientX - startX;
		let deltaY = event.clientY - startY;

		creditzj4v.style.left = (parseInt(origX) + deltaX) + 'px';
		creditzj4v.style.top  = (parseInt(origY) + deltaY) + 'px';
	}

	document.addEventListener('mouseup', () => {
		document.removeEventListener('mousemove', move);
	});
});
};
}

function closecreditzj4v() {

console.log('J4V Credits element was removed succesfully')
document.getElementById('creditzj4vid').remove();
  
}

function creditzzeakify() {

if (document.getElementById('creditzzeakifyid')) {
  document.getElementById('creditzzeakifyid').remove();
  } else {
  
  let creditzzeakify = document.createElement("div");
//style stuff
    creditzzeakify.style.background = "rgb(33, 33, 33)";
    creditzzeakify.style.width = "150px";
    creditzzeakify.style.height = "200px";
    creditzzeakify.style.position = "fixed";
    creditzzeakify.style.top = "0px";
    creditzzeakify.style.left = "0px";
    creditzzeakify.style.zIndex = "99999999";
    creditzzeakify.style.opacity = "0.85";
    creditzzeakify.style.borderRadius = "10px";
    creditzzeakify.style.border = "2px solid purple";
    creditzzeakify.style.fontFamily = "sans-serif";
    creditzzeakify.style.textAlign = "center";
    creditzzeakify.style.lineHeight = "0.1";
    creditzzeakify.style.fontWeight = "bold";
//end
creditzzeakify.id = "creditzzeakifyid"; //THIS IS THE ID IF YOU WANT TO USE IT.
//inner html
creditzzeakify.innerHTML = `
<style>
.hd {
  color: rgb(140, 0, 255);
  font-size:25px;
}

.pr {
  font-size: 10px;
  color:rgb(255,255,255);
  text-decoration: none;
}

.nbu { 
  color:white;
  background:transparent;
  border:solid 0px;
  width:150px;
  font-size:15px;
  transition: all 0.25s;
  border-radius: 10px;
  font-Weight:bold;
}

.nbu:hover {
  background: rgba(20, 20, 20);
  color: rgb(144, 0, 255);
  font-size:17px;
}

img {

border: 5px solid #6600e1;
border-radius: 45px;

}

h5 {
color: white;
}

</style>

<img id="zeakifyPFP" src="https://cdn.discordapp.com/avatars/751532308468859011/f0e85080b0f87e0e07811b72cbe211c6.webp?size=80">


  <h1 class="hd">Zeak<span style="color:rgb(0, 0, 0);text-shadow: 0px 0px 5px rgba(102,0,255,1), 0px 0px 5px rgba(102,0,255,1);">ify</span><h1>

<h5>Developer</h5>

<button id="closecreditzzeakify" class="nbu" style="position:absolute;bottom:5px;left:0px;">Exit</button>  
  `
document.body.appendChild(creditzzeakify);

//cheatzMenu menu button clicks (use getElementById)
  


 document.getElementById('closecreditzzeakify').onclick = closecreditzzeakify

  
creditzzeakify.addEventListener("mousedown", function(event) {
	let startX = event.clientX;
	let startY = event.clientY;
	let origX = creditzzeakify.style.left;
	let origY = creditzzeakify.style.top;

	document.addEventListener('mousemove', move);

	function move(event) {
		let deltaX = event.clientX - startX;
		let deltaY = event.clientY - startY;

		creditzzeakify.style.left = (parseInt(origX) + deltaX) + 'px';
		creditzzeakify.style.top  = (parseInt(origY) + deltaY) + 'px';
	}

	document.addEventListener('mouseup', () => {
		document.removeEventListener('mousemove', move);
	});
});
};
}

function closecreditzzeakify() {

console.log('Zeakify Credits element was removed succesfully')
document.getElementById('creditzzeakifyid').remove();
  
}

function creditzskyyy() {

if (document.getElementById('creditzskyyyid')) {
  document.getElementById('creditzskyyyid').remove();
  } else {

  let creditzskyyy = document.createElement("div");
//style stuff
    creditzskyyy.style.background = "rgb(33, 33, 33)";
    creditzskyyy.style.width = "150px";
    creditzskyyy.style.height = "200px";
    creditzskyyy.style.position = "fixed";
    creditzskyyy.style.top = "0px";
    creditzskyyy.style.left = "0px";
    creditzskyyy.style.zIndex = "99999999";
    creditzskyyy.style.opacity = "0.85";
    creditzskyyy.style.borderRadius = "10px";
    creditzskyyy.style.border = "2px solid purple";
    creditzskyyy.style.fontFamily = "sans-serif";
    creditzskyyy.style.textAlign = "center";
    creditzskyyy.style.lineHeight = "0.1";
    creditzskyyy.style.fontWeight = "bold";
//end
creditzskyyy.id = "creditzskyyyid"; //THIS IS THE ID IF YOU WANT TO USE IT.
//inner html
creditzskyyy.innerHTML = `
<style>
.hd {
  color: rgb(140, 0, 255);
  font-size:25px;
}

.pr {
  font-size: 10px;
  color:rgb(255,255,255);
  text-decoration: none;
}

.nbu { 
  color:white;
  background:transparent;
  border:solid 0px;
  width:150px;
  font-size:15px;
  transition: all 0.25s;
  border-radius: 10px;
  font-Weight:bold;
}

.nbu:hover {
  background: rgba(20, 20, 20);
  color: rgb(144, 0, 255);
  font-size:17px;
}

img {

border: 5px solid #6600e1;
border-radius: 45px;

}

h5 {
color: white;
}

</style>

<img id="ItzSkyyyPFP" src="https://cdn.discordapp.com/avatars/850289732511465484/46692bde0f9ee74ce160bf9a387710a1.webp?size=80">

  <h1 class="hd">Itz<span style="color:rgb(0, 0, 0);text-shadow: 0px 0px 5px rgba(102,0,255,1), 0px 0px 5px rgba(102,0,255,1);">Skyyy</span><h1>

<h5 color="white">Developer</h5>
<h5>Have a great day!</h5>

<button id="closecreditzskyyy" class="nbu" style="position:absolute;bottom:5px;left:0px;">Exit</button>  
  `
document.body.appendChild(creditzskyyy);

//cheatzMenu menu button clicks (use getElementById)
  


 document.getElementById('closecreditzskyyy').onclick = closecreditzskyyy

  
creditzskyyy.addEventListener("mousedown", function(event) {
	let startX = event.clientX;
	let startY = event.clientY;
	let origX = creditzskyyy.style.left;
	let origY = creditzskyyy.style.top;

	document.addEventListener('mousemove', move);

	function move(event) {
		let deltaX = event.clientX - startX;
		let deltaY = event.clientY - startY;

		creditzskyyy.style.left = (parseInt(origX) + deltaX) + 'px';
		creditzskyyy.style.top  = (parseInt(origY) + deltaY) + 'px';
	}

	document.addEventListener('mouseup', () => {
		document.removeEventListener('mousemove', move);
	});
});
};
}

function closecreditzskyyy() {

console.log('ItzSkyyy Credits element was removed succesfully')
document.getElementById('creditzskyyyid').remove();
  
}



//
//
//
//
//
//
//end of credits profiles
function closemenu() {
  alert("Successfully deleted VoidMenu menu off of your screen. To get it again, reload the page.") 
document.getElementById('jav').remove();
};


//made by itzskyyy ( I STAYED UP UNTIL 3:40 AM CDT FOR TO MAKE THIS SHIT CAUSE I COULDNT FIND 1 DUMB ASS ERROR )

//skill issue -Zeakify

function OpenGPT() {

if (document.getElementById('gptmenu')) {
  document.getElementById('gptmenu').remove();
  } else {
  
let gptmenu = document.createElement("div");
//style stuff
    gptmenu.style.background = "rgb(33, 33, 33)";
    gptmenu.style.width = "200px";
    gptmenu.style.height = "290px";
    gptmenu.style.position = "fixed";
    gptmenu.style.top = "0px";
    gptmenu.style.left = "0px";
    gptmenu.style.zIndex = "99999999";
    gptmenu.style.opacity = "0.85";
    gptmenu.style.borderRadius = "10px";
    gptmenu.style.border = "2px solid purple";
    gptmenu.style.fontFamily = "sans-serif";
    gptmenu.style.textAlign = "center";
    gptmenu.style.lineHeight = "0.1";
    gptmenu.style.fontWeight = "bold";
//end
gptmenu.id = "gptmenu"; //THIS IS THE ID IF YOU WANT TO USE IT.
//inner html
gptmenu.innerHTML = `
<style>
.hd {
  color: rgb(140, 0, 255);
  font-size:25px;
}

.subhd {
  color: rgb(140, 0, 255);
  font-size:15px;
}

.pr {
  font-size: 10px;
  color:rgb(255,255,255);
  text-decoration: none;
}

.nbuexit { 
  color:white;
  background:transparent;
  border:solid 0px;
  width:300px;
  font-size:15px;
  transition: all 0.25s;
  border-radius: 10px;
  font-Weight:bold;
}

.nbuexit:hover {
  background: rgba(20, 20, 20);
  color: rgb(144, 0, 255);
  font-size:17px;
}

.nbu { 
  color:white;
  background:transparent;
  border:solid 0px;
  width:150px;
  font-size:15px;
  transition: all 0.25s;
  border-radius: 10px;
  font-Weight:bold;
}

.nbu:hover {
  background: rgba(20, 20, 20);
  color: rgb(144, 0, 255);
  font-size:17px;
}

.hd {
      color: rgb(140, 0, 255);
      font-size: 25px;
    }

    .subhd {
      color: rgb(140, 0, 255);
      font-size: 15px;
    }

    .pr {
      font-size: 10px;
      color: rgb(255, 255, 255);
      text-decoration: none;
    }

    .nbuexit {
      color: white;
      background: transparent;
      border: solid 0px;
      width: 200px;
      font-size: 15px;
      transition: all 0.25s;
      border-radius: 10px;
      font-weight: bold;
    }

    .nbuexit:hover {
      background: rgba(20, 20, 20);
      color: rgb(144, 0, 255);
      font-size: 17px;
    }

    .nbu {
      color: white;
      background: transparent;
      border: solid 0px;
      width: 150px;
      font-size: 15px;
      transition: all 0.25s;
      border-radius: 10px;
      font-weight: bold;
    }

    .nbu:hover {
      background: rgba(20, 20, 20);
      color: rgb(144, 0, 255);
      font-size: 17px;
    }

    #input {
      width: 140px;
      height: 50px;
      margin: 10px;
      padding: 10px;
      font-family: sans-serif;
      font-size: 15px;
      border-radius: 10px;
      border: 2px solid purple;
      resize: none;
      background-color:black;
      color:purple;
    }

    #response {
      width: 140px;
      height: 50px;
      margin: 10px;
      padding: 10px;
      font-family: sans-serif;
      font-size: 15px;
      border-radius: 10px;
      border: 2px solid purple;
      resize: none;
      overflow-y: auto;
      background-color:black;
      color:purple;
    }

    #response::-webkit-scrollbar-thumb {
      background-color: purple;
      border-radius: 10px;
    }

    #response::-webkit-scrollbar-track {
      background-color: black;
      border: solid 2x purple;
    }

</style>

  <h1 class="hd">Chat<span style="color:rgb(0, 0, 0);text-shadow: 0px 0px 5px rgba(102,0,255,1), 0px 0px 5px rgba(102,0,255,1);">GPT</span><h1>

  <p class="subhd">text-davinci-003<p>
<form>
  <input type="text" id="input" name="input" placeholder="Type your message here">
  </form>
  <form id="response-form">
  <textarea id="response" name="response" placeholder="Output will appear here" readonly></textarea>
  </form>
  
<button id="closegpt" class="nbuexit" style="position:absolute;bottom:3px;left:0px;">Exit</button>  
  `
document.body.appendChild(gptmenu);
//end of contents
  
document.getElementById('closegpt').onclick = closegptmenu


//Made by ItzSkyyy
 const API_KEY = "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";
   
    const ENGINE = "text-davinci-003";

    const form = document.querySelector("form");
   
    const input = document.getElementById('input');
   
    const response = document.querySelector("#response");

    

   
    form.addEventListener('submit', function(e) {
      e.preventDefault();
      
      const message = input.value;
     
      input.value = "";
      
      sendMessage(message);
    });



  
    
    function sendMessage(message) {
      
      const xhr = new XMLHttpRequest();
      
      xhr.open("POST", `https://api.openai.com/v1/engines/${ENGINE}/completions`);
      
      xhr.setRequestHeader("Content-Type", "application/json");
      xhr.setRequestHeader("Authorization", `Bearer ${API_KEY}`);
      
      xhr.onload = function() {
        if (xhr.status === 200) {
          
          const data = JSON.parse(xhr.responseText);
          
          const responseMessage = data.choices[0].text;
          
          response.innerHTML = responseMessage;
        } else {
          console.error("Error sending message to OpenAI API: " + xhr.status);
        }
      };
     
      xhr.send(JSON.stringify({
        prompt: message,
        max_tokens: 2048,
      }));
    }





  
  
//draggable menu function.
gptmenu.addEventListener("mousedown", function(event) {
	let startX = event.clientX;
	let startY = event.clientY;
	let origX = gptmenu.style.left;
	let origY = gptmenu.style.top;

	document.addEventListener('mousemove', move);

	function move(event) {
		let deltaX = event.clientX - startX;
		let deltaY = event.clientY - startY;

		gptmenu.style.left = (parseInt(origX) + deltaX) + 'px';
		gptmenu.style.top  = (parseInt(origY) + deltaY) + 'px';
	}

	document.addEventListener('mouseup', () => {
		document.removeEventListener('mousemove', move);
	});
});
};
}




function closegptmenu() {
  
console.log('gptmenu element was removed succesfully')
document.getElementById('gptmenu').remove();
  
}


function diskard() {
  window.open('https://discord.gg/voidmenu')
}

function openCheatz() {

if (document.getElementById('cheetz')) {
  document.getElementById('cheetz').remove();
  } else {
  
  let cheatzMenu = document.createElement("div");
//style stuff
    cheatzMenu.style.background = "rgb(33, 33, 33)";
    cheatzMenu.style.width = "150px";
    cheatzMenu.style.height = "200px";
    cheatzMenu.style.position = "fixed";
    cheatzMenu.style.top = "0px";
    cheatzMenu.style.left = "0px";
    cheatzMenu.style.zIndex = "99999999";
    cheatzMenu.style.opacity = "0.85";
    cheatzMenu.style.borderRadius = "10px";
    cheatzMenu.style.border = "2px solid purple";
    cheatzMenu.style.fontFamily = "sans-serif";
    cheatzMenu.style.textAlign = "center";
    cheatzMenu.style.lineHeight = "0.1";
    cheatzMenu.style.fontWeight = "bold";
//end
cheatzMenu.id = "cheetz"; //THIS IS THE ID IF YOU WANT TO USE IT.
//inner html
cheatzMenu.innerHTML = `
<style>
.hd {
  color: rgb(140, 0, 255);
  font-size:25px;
}

.pr {
  font-size: 10px;
  color:rgb(255,255,255);
  text-decoration: none;
}

.nbu { 
  color:white;
  background:transparent;
  border:solid 0px;
  width:150px;
  font-size:15px;
  transition: all 0.25s;
  border-radius: 10px;
  font-Weight:bold;
}

.nbu:hover {
  background: rgba(20, 20, 20);
  color: rgb(144, 0, 255);
  font-size:17px;
}

</style>

  <h1 class="hd">Void<span style="color:rgb(0, 0, 0);text-shadow: 0px 0px 5px rgba(102,0,255,1), 0px 0px 5px rgba(102,0,255,1);">Cheats</span><h1>

<button id="ireadyCheatsbtn" class="nbu" style="position:absolute;top:40px;left:0px;">i-Ready Cheats</span></button> 

<button id="closeCheatz" class="nbu" style="position:absolute;bottom:5px;left:0px;">Exit</button>  
  `
document.body.appendChild(cheatzMenu);

//cheatzMenu menu button clicks (use getElementById)
  
  document.getElementById('ireadyCheatsbtn').onclick = openIreadyCheats

 document.getElementById('closeCheatz').onclick = closeCheatz


  cheatzMenu.addEventListener("mousedown", function(event) {
	let startX = event.clientX;
	let startY = event.clientY;
	let origX = cheatzMenu.style.left;
	let origY = cheatzMenu.style.top;

	document.addEventListener('mousemove', move);

	function move(event) {
		let deltaX = event.clientX - startX;
		let deltaY = event.clientY - startY;

		cheatzMenu.style.left = (parseInt(origX) + deltaX) + 'px';
		cheatzMenu.style.top  = (parseInt(origY) + deltaY) + 'px';
	}

	document.addEventListener('mouseup', () => {
		document.removeEventListener('mousemove', move);

  });
});
};
}

function closeCheatz() {

console.log('cheetz element was removed succesfully')
document.getElementById('cheetz').remove();
  
}


//cheatz functions
function openIreadyCheats() {

if (document.getElementById('irady')) {
  document.getElementById('irady').remove();
  } else {
  
  let ireadyCheats = document.createElement("div");
  //style stuff
    ireadyCheats.style.background = "rgb(33, 33, 33)";
    ireadyCheats.style.width = "150px";
    ireadyCheats.style.height = "200px";
    ireadyCheats.style.position = "fixed";
    ireadyCheats.style.top = "0px";
    ireadyCheats.style.left = "0px";
    ireadyCheats.style.zIndex = "99999999";
    ireadyCheats.style.opacity = "0.85";
    ireadyCheats.style.borderRadius = "10px";
    ireadyCheats.style.border = "2px solid purple";
    ireadyCheats.style.fontFamily = "sans-serif";
    ireadyCheats.style.textAlign = "center";
    ireadyCheats.style.lineHeight = "0.1";
    ireadyCheats.style.fontWeight = "bold";
  //end
  ireadyCheats.id = "irady"; //THIS IS THE ID IF YOU WANT TO USE IT.
  //inner html
  ireadyCheats.innerHTML = `
  <style>
  .hd {
    color: rgb(140, 0, 255);
    font-size:25px;
  }
  
  .pr {
    font-size: 10px;
    color:rgb(255,255,255);
    text-decoration: none;
  }
  
  .nbu { 
    color:white;
    background:transparent;
    border:solid 0px;
    width:150px;
    font-size:15px;
    transition: all 0.25s;
    border-radius: 10px;
    font-Weight:bold;
  }
  
  .nbu:hover {
    background: rgba(20, 20, 20);
    color: rgb(144, 0, 255);
    font-size:17px;
  }

  </style>
  
    <h1 class="hd">i<span style="color:rgb(0, 0, 0);text-shadow: 0px 0px 5px rgba(102,0,255,1), 0px 0px 5px rgba(102,0,255,1);">-Ready</span><h1>
  
  <button id="skeparr" class="nbu" style="position:absolute;top:40px;left:0px; color:grey; disabled">Skip Lesson</span></button> 
  
  <button id="duparr" class="nbu" style="position:absolute;top:60px;left:0px;">Dupe Lesson</span></button> 
  
  <button id="manutefrmr" class="nbu" style="position:absolute;top:80px;left:0px;">Farm Minutes</span></button> 
  
  <button id="xtras" class="nbu" style="position:absolute;top:100px;left:0px;">Extras</span></button> 
    
  <button id="closeIreadyCheats" class="nbu" style="position:absolute;bottom:5px;left:0px;">Exit</button>  
    `
  document.body.appendChild(ireadyCheats);

document.getElementById('skeparr').onclick = skeparr

document.getElementById('duparr').onclick = duparr

document.getElementById('manutefrmr').onclick = manutefrmr

document.getElementById('xtras').onclick = xtras

document.getElementById('closeIreadyCheats').onclick = closeIreadyCheats
  

ireadyCheats.addEventListener("mousedown", function(event) {
	let startX = event.clientX;
	let startY = event.clientY;
	let origX = ireadyCheats.style.left;
	let origY = ireadyCheats.style.top;

	document.addEventListener('mousemove', move);

	function move(event) {
		let deltaX = event.clientX - startX;
		let deltaY = event.clientY - startY;

		ireadyCheats.style.left = (parseInt(origX) + deltaX) + 'px';
		ireadyCheats.style.top  = (parseInt(origY) + deltaY) + 'px';
	}

	document.addEventListener('mouseup', () => {
		document.removeEventListener('mousemove', move);
	});
});
};
}
  //ireadyCheats menu Functions

function closeIreadyCheats() {

console.log('irady element was removed succesfully')
document.getElementById('irady').remove();
  
}

function skeparr() {
  alert("Skipper is patched. We are currently working on it. Use chat GPT or lesson dupe for i-Ready answer hacks.")
}

function duparr() {
  alert("Lesson has been duplicated 3 times, you may get answers.")
  var dadupe = document.getElementById('html5Iframe').src;
  open(dadupe);
  open(dadupe);
  open(dadupe);
}

function manutefrmr() {
  alert('Minute farmer has been enabled. Refresh your page to stop the minute farmer.')
  setInterval(function(){
    document.getElementById('play-pause').click();
}, 20000);
}

//the extra i-Ready menu - j6x
function xtras() {
    if (document.getElementById('moare')) {
  document.getElementById('moare').remove();
  } else {
    var more2 = document.createElement("div");
    more2.style.background = "rgb(33, 33, 33)";
    more2.style.width = "150px";
    more2.style.height = "200px";
    more2.style.position = "fixed";
    more2.style.top = "0px";
    more2.style.left = "0px";
    more2.style.zIndex = "99999999";
    more2.style.opacity = "0.85";
    more2.style.borderRadius = "10px";
    more2.style.border = "2px solid purple";
    more2.style.fontFamily = "sans-serif";
    more2.style.textAlign = "center";
    more2.style.lineHeight = "0.1";
    more2.style.fontWeight = "bold";
    //more2 id
    more2.id = "moare";
more2.innerHTML = `
  <style>
  .hd {
    color: rgb(140, 0, 255);
    font-size:25px;
  }
  
  .pr {
    font-size: 10px;
    color:rgb(255,255,255);
    text-decoration: none;
  }
  
  .nbu { 
    color:white;
    background:transparent;
    border:solid 0px;
    width:150px;
    font-size:15px;
    transition: all 0.25s;
    border-radius: 10px;
    font-Weight:bold;
  }
  
  .nbu:hover {
    background: rgba(20, 20, 20);
    color: rgb(144, 0, 255);
    font-size:17px;
  }

  </style>
<h1 class="hd" style="font-family: sans-serif;text-align:center;">Extras</h1>

<button class="nbu" id="coinz">Change Coins</button>

<button class="nbu" id="namez">Change Name</button>

<button class="nbu" id="fics">Fix Lesson</button>

<button class="nbu" id="leslink">Lesson Link</button>

<button class="nbu" id="gamefree">Free games</button>

<button class="nbu" id="dark">Dark mode</button>

<button id="closeExtraz" class="nbu" style="position:absolute;bottom:5px;left:0px;">Exit</button>  
` 
  };

document.body.appendChild(more2);

  
//extra button clicks
document.getElementById('coinz').onclick = coins;
document.getElementById('namez').onclick = namechanger;
document.getElementById('fics').onclick = fixLesson;
document.getElementById('leslink').onclick = leslink;
document.getElementById('closeExtraz').onclick = closeExtraz;
document.getElementById('dark').onclick = dark;
document.getElementById('gamefree').onclick = gamefree;

moare.addEventListener("mousedown", function(event) {
	let startX = event.clientX;
	let startY = event.clientY;
	let origX = more2.style.left;
	let origY = more2.style.top;

	document.addEventListener('mousemove', move);

	function move(event) {
		let deltaX = event.clientX - startX;
		let deltaY = event.clientY - startY;

		moare.style.left = (parseInt(origX) + deltaX) + 'px';
		moare.style.top  = (parseInt(origY) + deltaY) + 'px';
	}

	document.addEventListener('mouseup', () => {
		document.removeEventListener('mousemove', move);
	});
});
};


function closeExtraz() {

console.log('xtra element was removed succesfully')
document.getElementById('moare').remove();
  
}


function dark() {
  console.log("Dark mode on.")
  var sub = document.getElementsByClassName('e1nmn77d1-card-body embu0a00 css-1kh7anh-createComponent-withSubjectPickerStyles-HEADER_9 node_modules--cainc-cauliflower-src-components-card-___Card__card-body')[0];
sub.style.background  = "black";

//background
document.body.style.background = "black";

//name & coin thingy
var namzcoin = document.getElementsByClassName('node_modules--cainc-cauliflower-src-components-layout-___Layout__layout-flex node_modules--cainc-cauliflower-src-components-layout-___Layout__align-items-center node_modules--cainc-cauliflower-src-components-layout-___Layout__justify-content-space-between css-t7oxu9-Layout-UsernameContainer e15psnz1')[0];
namzcoin.style.background = "#2C2C2C";

document.getElementById('firstname').style.color = "white";
document.getElementById('coin-amount').style.color = "white";
  
  //u guys can edit this if you know what your doing
}


function gamefree() {
window.open('https://docs.google.com/document/d/1Y5rPs6YQtTpp5HAiE6HTuesLxHHf53VTa41nvqF7uHk/view')
}

function coins() {
  
  let coins = prompt("How many coins do you want?", "10,000");
document.getElementsByClassName('css-1ha21nc-Typography enj526p0')[0].innerHTML=coins
alert("You have " + coins + " coins. (ITS ONLY FOR SHOW)")
}

function namechanger() {
  
let namechange = prompt("Put anything inside the box.", "Ethan");
document.getElementsByClassName('css-1lvadjd-Typography-Username e15psnz0')[0].innerHTML=namechange
}

function leslink() {
if (window['html5Iframe'] === undefined) {
alert("Please open a lesson.")
} else {
var iframeLink = window["html5Iframe"].src;
alert("Your lesson link is: " + iframeLink);
}
};


function fixLesson() {
  
let csid = html5Iframe.src.split("?csid=")[1].split("&type")[0];
fetch(`https://login.i-ready.com/student/v2/web/lesson_component/${csid}/markprogress/${csid}`, {
"headers": {
  "accept": "application/json, text/plain, */*",
  "accept-language": "en-US,en;q=0.9",
  "content-type": "application/json;charset=UTF-8",
  "sec-fetch-dest": "empty",
  "sec-fetch-mode": "cors",
  "sec-fetch-site": "same-origin",
  "sec-gpc": "1",
},
"referrer": "https://login.i-ready.com/student/dashboard/home",
"referrerPolicy": "strict-origin-when-cross-origin",
"body": `{\"value\":\"a",\"bucket\":\"short_term_unsecured\",\"datatype\":\"json\"}`,
"method": "POST",
"mode": "cors",
"credentials": "include"
});
alert("Your lesson should be fixed. If not, report a issue in discord.")
}


//console.log stuff

    console.log('%cVoidMenu', 'color: #8000FF;font-size: 60px;font-family:sans-serif;');
  console.log('%cMade by J4V, Zeakify & ItzSkyyy.', 'color:#8000FF;font-size: 30px;');